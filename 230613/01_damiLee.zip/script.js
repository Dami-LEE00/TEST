setInterval(() => {
  const now = new Date();

  const h = now.getHours();
  const m = now.getMinutes();
  const s = now.getSeconds();

  const degH = h * (360 / 12) + m * (360 / 12 / 60);
  const degM = m * (360 / 60);
  const degS = s * (360 / 60);

  const lineHour = document.querySelector(".lineHour");
  const lineMin = document.querySelector(".lineMin");
  const lineSec = document.querySelector(".lineSec");

  lineHour.style.transform = `rotate(${degH}deg)`;
  lineMin.style.transform = `rotate(${degM}deg)`;
  lineSec.style.transform = `rotate(${degS}deg)`;
}, 1000);