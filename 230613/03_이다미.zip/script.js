const input = document.querySelector(".localStorage input");
const btnSave = document.querySelector(".btnSave");
const btnRemove = document.querySelector(".btnRemove");
const btnClear = document.querySelector(".btnClear");

btnSave.addEventListener("click", () => {
  localStorage.setItem('mykey', JSON.stringify(input.value));
  input.value = "";
});

btnRemove.addEventListener("click", () => {
  localStorage.removeItem('mykey');
});

btnClear.addEventListener("click", () => {
  localStorage.clear();
});