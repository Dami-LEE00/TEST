const input = document.querySelector(".localStorage input");
const btnSave = document.querySelector(".btnSave");
const btnRead = document.querySelector(".btnRead");

btnSave.addEventListener("click", () => {
  localStorage.setItem('mykey', JSON.stringify(input.value));
  input.value = "";
});

btnRead.addEventListener("click", () => {
  let localData = JSON.parse(localStorage.getItem('mykey'));
  input.value = localData;
});
