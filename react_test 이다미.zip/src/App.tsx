import React, { useState, useEffect } from 'react';
import { styled } from 'styled-components';

const Wrap = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  height: 100vh;
`;
const Container = styled.div`
  box-shadow: 5px 5px 40px rgba(65, 153, 225, 0.6);
  width: 480px;
  padding: 50px 60px 80px 60px;
`;
const Title = styled.h1`
  color: #176edf;
  margin-bottom: 60px;
`;
const Form = styled.div`
  display: flex;
  flex-direction: column;
  gap: 30px;
`;
const Section = styled.div`
  display: flex;
  flex-direction: column;
  gap: 5px;
`;
const Label = styled.div`
  color: #999;
  font-size: 16px;
  font-weight: bold;
`;
const Input = styled.input`
  padding: 10px 5px;
  font-size: 16px;
  outline: none;
  border: none;
  border-bottom: 1px solid #d9d9d9;
  &:focus {
    border-bottom: 1px solid #176edf;
  }
`;
const Gender = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 15px;
`;
const Agree = styled.div`
  display: flex;
  flex-direction: row;
  justify-content: center;
  align-items: center;
  gap: 5px;
  font-size: 12px;
`;
const Button = styled.button`
  outline: none;
  border: 1px solid #176edf;
  color: #176edf;
  background-color: #fff;
  padding: 15px;
  border-radius: 10px;
  font-size: 18px;
`;

function App() {
  const [email, setEmail] = useState("");
  const [name, setName] = useState("");
  const [pw, setPw] = useState("");
  const [chkpw, setChkpw] = useState("");
  const [errors, setErrors] = useState({
    email: "",
    name: "",
    pw: "",
    chkpw: "",
  });

  useEffect(() => {
    // 입력값 변경 시 상태 업데이트
    setEmail(email);
    setName(name);
    setPw(pw);
    setChkpw(chkpw);
  }, [email, name, pw, chkpw]);

  const handleSignUp = () => {
    const newErrors = {
      email: "",
      name: "",
      pw: "",
      chkpw: "",
    };

    if (!email) {
      newErrors.email = "이메일이 비어있습니다.";
    }

    if (!name) {
      newErrors.name = "이름이 비어있습니다.";
    }

    if (!pw) {
      newErrors.pw = "비밀번호가 비어있습니다.";
    }

    if (!chkpw) {
      newErrors.chkpw = "비밀번호 확인이 비어있습니다.";
    } else if (pw !== chkpw) {
      newErrors.chkpw = "비밀번호가 일치하지 않습니다.";
    }

    setErrors(newErrors);

    if (Object.values(newErrors).every((error) => error === "")) {
      // 가입 로직 실행
    }
  };

  return (
    <Wrap>
      <Container>
        <Title>
          회원가입을 위해<br />
          정보를 입력해주세요
        </Title>
        <Form>
          <Section>
            <Label>* 이메일</Label>
            <Input
              type="text"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            {errors.email && <p style={{ color: 'red' }}>{errors.email}</p>}
          </Section>
          <Section>
            <Label>* 이름</Label>
            <Input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
            {errors.name && <p style={{ color: 'red' }}>{errors.name}</p>}
          </Section>
          <Section>
            <Label>* 비밀번호</Label>
            <Input
              type="password"
              value={pw}
              onChange={(e) => setPw(e.target.value)}
            />
            {errors.pw && <p style={{ color: 'red' }}>{errors.pw}</p>}
          </Section>
          <Section>
            <Label>* 비밀번호 확인</Label>
            <Input
              type="password"
              value={chkpw}
              onChange={(e) => setChkpw(e.target.value)}
            />
            {errors.chkpw && <p style={{ color: 'red' }}>{errors.chkpw}</p>}
          </Section>
          <Gender>
            <div>
              <input type="radio" name="gender" />
              <label>여성</label>
            </div>
            <div>
              <input type="radio" name="gender" />
              <label>남성</label>
            </div>
          </Gender>
          <Agree>
            <input type="checkbox" />
            <label>
              이용약관 개인정보 수집 및 이름, 마케팅 활용 선택에 모두 동의합니다.
            </label>
          </Agree>
          <hr />
          <Button className="btnJoin" onClick={handleSignUp}>
            가입하기
          </Button>
        </Form>
      </Container>
    </Wrap>
  );
}

export default App;
